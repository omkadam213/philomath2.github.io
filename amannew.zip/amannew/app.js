require('dotenv').config()
const express = require('express')
const bodyparser = require('body-parser')
const request = require("request");
const https = require("https")
const ejs = require('ejs')
const mongoose = require('mongoose');
const nodemailer = require('nodemailer')



// Mongodb connection url
mongoose.connect("mongodb://localhost:27017/philomath", { useNewUrlParser: true })

const userSchema = new mongoose.Schema({
    fullName: String,
    Email: String,
    Number: String,
    GraduationYear: String,
    City: String

});

const philoData = mongoose.model("philoData", userSchema)


const app = express();

app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public/'));
app.use(bodyparser.urlencoded({ extended: true }))




app.get("/", function(req, res) {

    res.render("index")


});


app.get("/contactus", function(req, res) {
    res.render("contactus")
})



app.get("/userscolt", function(req, res) {
    philoData.find({}, function(err, userdata) {
        res.render("usercolt", {
            posts: userdata
        });
    });
})


app.post("/contactus.ejs", function(req, res) {
    const fullname = req.body.fullname
    const email = req.body.email
    const number = req.body.number
    const GraduationYear = req.body.GraduationYear
    const city = req.body.city


    const data = new philoData({
        fullName: fullname,
        Email: email,
        Number: number,
        GraduationYear: GraduationYear,
        City: city

    })
    data.save()

    res.redirect("/")

    const transport = nodemailer.createTransport(

        {
            service: "gmail",
            auth: {
                user: process.env.GMAIL_ID,
                pass: process.env.GMAIL_PASS

            }
        }


    )

    // Send out emails

    var mailOptions = {
        from: process.env.GMAIL_ID,
        to: email,
        subject: "Hello world this is a test mail",
        text: "this is the body of the mail",
        attachments: [{
            filename: 'Philomath.pdf',
            path: __dirname + '/public/images/Philomath.pdf'
        }]
    }

    transport.sendMail(mailOptions, function(error, info) {
        if (error) {
            console.log(error)
        } else {
            console.log("Email sent")
        }
    })



})


app.listen(process.env.PORT || 1000, function() {
    console.log("server is running successfully on port made by om kadam");
})