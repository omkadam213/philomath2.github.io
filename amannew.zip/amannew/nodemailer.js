const nodemailer = require('nodemailer')

const transport = nodemailer.createTransport(

    {
        service: "gmail",
        auth: {
            user: "om.vkadam13@gmail.com",
            pass: "Indianarmy@13"

        }
    }


)

// Send out emails

var mailOptions = {
    from: "om.vkadam13@gmail.com",
    to: "om.vkadam13@gmail.com",
    subject: "Hello world this is a test mail",
    text: "this is the body of the mail"
}

transport.sendMail(mailOptions, function(error, info) {
    if (error) {
        console.log(error)
    } else {
        console.log("Email sent")
    }
})